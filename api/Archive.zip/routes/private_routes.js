
let middleware = require('../middleware');
var userController = require('../components/users/userController');
const resources = require('../components/event_and_resources/resources');

module.exports = function (app) {

    var checkExpireToken = middleware.checkToken;
    var checkAccess = middleware.checkAccess;



    app.get('/users',checkExpireToken, (req, res, cb) => { addHeader(req, res, cb, resources.UserRead) }, checkAccess,userController.List)
       .get('/user',checkExpireToken, (req, res, cb) => { addHeader(req, res, cb, resources.UserRead) }, checkAccess,userController.One)


}



function addHeader(req, res, cb, access) {
    req.query.access = access; cb()
}
