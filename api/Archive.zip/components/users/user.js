var mongoose = require("mongoose");
var bcrypt = require("bcrypt");
mongoose.Promise = global.Promise;
var userSchema = mongoose.Schema({
  full_name: {
    type: String,
    trim:true,
  },
  user_name: {
    type: String,
    lowercase: true,
    trim:true
  },
  email: {
    type: String,
    trim:true,
    lowercase: true,
    default: "unnkown@example.com",
  },
  password: { type: String },
  card_no: { type: String },
  phone: { type: String },
  job_title: { type: String },
  profile_photo: {
    type: String,
    default: "avatar.png",
  },
  role_id: {
    type: mongoose.Schema.ObjectId,
    ref: "Role",
    default: null,
  },
  creator: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
    default: null,
  },
  editor: {
    type: mongoose.Schema.ObjectId,
    ref: "User",
    default: null,
  },
  created_at: {
    type: Date,
    default: Date.now(),
  },
  updated_at: {
    type: Date,
    default: Date.now(),
  },
  deleted_at: {
    type: Date,
    default: null
  },
  active: {
    type: Boolean,
    default: true,
  },
  resetPasswordToken: {
    type: String,
    default: "",
  },
  resetPasswordExpires: {
    type: Date,
    default: "",
  },
});

userSchema.methods.validation = async function (body, key) {

    return ({ status: true });

}

userSchema.virtual("User", {
  ref: "User", // The model to use
  localField: "_id", // Find people where `localField`
  foreignField: "user", // is equal to `foreignField`
  justOne: false,
});


// generating a hash
userSchema.methods.generateHash = function (password) {
  return bcrypt.hashSync(password, bcrypt.genSaltSync(10), null);
};

// checking if password is valid
userSchema.methods.validPassword = function (password) {
  return bcrypt.compareSync(password, this.password);
};

// create the model for users and expose it to our app
module.exports = mongoose.model("User", userSchema);
