const User = require("./user");


exports.newData = async (req, res) => {
    var newData = new User(req.body);
    // var validate = await newData.validation(req.body, 'create')
//     if (!validate.status) {
//       res.json({ status: false, message: validate.message });
//       return 0;
//    }


    newData.creator = req.query.userID;
    newData.created_at = Date.now();
    newData.updated_at = Date.now();
    newData.save(function (err, res) {
      if (err) throw err;
      else {
        res.json({ status: true, message: "User has been created" });
        return 0;
      }
    });
  };


exports.List = async( req,res)=>{
  
    var users = await User.find({ $and: [{ deleted_at: null }, search] })
    .populate('creator')
    .skip(parseInt(req.query.skip))
    .limit(parseInt(req.query.limit))
    .sort(req.query.sort)
    .exec();

  var count = await User.countDocuments({ $and: [{ deleted_at: null }, search] })
    .exec();

  if (users.length == 0) {
    res.json({ status: false, message: "users not found" });
    return 0;
  } else {
    res.json({ status: true, count, data: roles, message: "list role" });
    return 0;
  }
}

exports.One = async( req,res)=>{

    if (!req.query._id) {
        res.json({ status: false, message: "Role ID required" });
        return 0;
      }
      var _id = req.query._id;
    
      var roles = await Role.findOne({ $and: [{ deleted_at: null }, { _id: _id }] })
        .exec();
      if (!roles) {
        res.json({ status: false, message: "Role not found" });
        return 0;
      } else {
        res.json({ status: true, data: roles, message: "list role" });
        return 0;
      }
    
}