module.exports = {
    secret: 'HalabjaGroupRecruitment#2022'
  };