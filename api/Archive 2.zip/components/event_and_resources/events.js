module.exports = {
  
  CreateUser: "user-create",
  UpdateUser: "user-update",
  DeleteUser: "user-delete",

  CreateRole: "role-create",
  UpdateRole: "role-update",
  DeleteRole: "role-delete",

 
  LoginFailedIncorectData: "login-failed-incoreect-data",
  LoginFailedUserActivation: "login-failed-user-inactive",
  LoginSuccess: "login-success",

 
};
